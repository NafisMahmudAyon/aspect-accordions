import { render } from "@wordpress/element";
import React from "react";
import AccordionEditor from "./components/AccordionEditor";
import "./index.css";

render(<AccordionEditor />, document.getElementById("aspect-accordions-app"));
