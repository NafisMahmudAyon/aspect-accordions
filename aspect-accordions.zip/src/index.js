import ReactDOM from "react-dom";
import React from "react";
import AccordionEditor from "./components/AccordionEditor";
import "./index.css";

ReactDOM.render(<AccordionEditor />, document.getElementById("aspect-accordions-app"));
