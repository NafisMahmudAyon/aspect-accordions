import clsx from "clsx";

const cn = (...args) => {
	return clsx(args);
};
export { cn };
