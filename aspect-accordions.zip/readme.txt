=== Aspect Accordions - With Tailwind Style ===
	Contributors: nafismahmudayon
	Tags: accordion, FAQ
	Requires at least: 3.8
	Tested up to: 6.7
	Stable tag: 0.0.1
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	Create accordion, faq, tabs, tab content via shortcode and display anywhere under post, page or widget and page
	builder elements.

== Description ==

Accordions is easy and powerful tool to create accordion, faq, tabs, tab content, frequently asked question, knowledge base, question & answer section, WooCommerce FAQ tabs and many other way to use this plugin. supper easy to customize looks and feel, changing color, font size of content, choosing accordion icons was never easy before.

== Changelog ==

== 0.0.1 ==

* Initial release